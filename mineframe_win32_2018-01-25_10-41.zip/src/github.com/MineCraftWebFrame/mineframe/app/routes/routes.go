// GENERATED CODE - DO NOT EDIT
package routes

import "github.com/revel/revel"


type tApp struct {}
var App tApp


func (_ tApp) Index(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("App.Index", args).URL
}

func (_ tApp) Hello(
		myName string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "myName", myName)
	return revel.MainRouter.Reverse("App.Hello", args).URL
}


type tMfApi struct {}
var MfApi tMfApi


func (_ tMfApi) ServiceWS(
		ws interface{},
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "ws", ws)
	return revel.MainRouter.Reverse("MfApi.ServiceWS", args).URL
}

func (_ tMfApi) ServicetStatus(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("MfApi.ServicetStatus", args).URL
}

func (_ tMfApi) ServiceStart(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("MfApi.ServiceStart", args).URL
}

func (_ tMfApi) ServiceStop(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("MfApi.ServiceStop", args).URL
}

func (_ tMfApi) ServiceRestart(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("MfApi.ServiceRestart", args).URL
}

func (_ tMfApi) MinecraftConfigRead(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("MfApi.MinecraftConfigRead", args).URL
}

func (_ tMfApi) MinecraftConfigUpdate(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("MfApi.MinecraftConfigUpdate", args).URL
}


type tStatic struct {}
var Static tStatic


func (_ tStatic) Serve(
		prefix string,
		filepath string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "prefix", prefix)
	revel.Unbind(args, "filepath", filepath)
	return revel.MainRouter.Reverse("Static.Serve", args).URL
}

func (_ tStatic) ServeModule(
		moduleName string,
		prefix string,
		filepath string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "moduleName", moduleName)
	revel.Unbind(args, "prefix", prefix)
	revel.Unbind(args, "filepath", filepath)
	return revel.MainRouter.Reverse("Static.ServeModule", args).URL
}


